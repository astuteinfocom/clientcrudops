import tkinter as tk
from tkinter import messagebox
import os

# Function to verify the login
def login():
    username = username_var.get()
    password = password_var.get()
    
    if username == "admin" and password == "admin":
        messagebox.showinfo("Login", "Login Successful!")
        win.destroy()  # Close the login window
        os.system('python dataload.py')  # Redirect to dataload.py
    else:
        messagebox.showerror("Error", "Invalid Username or Password")

# Create the main window
win = tk.Tk()
win.title("ATTENDANCE MANAGEMENT SYSTEM")
win.geometry("500x400")
win.configure(bg="#f0f0f0")  # Background color

# Title/Heading
title_label = tk.Label(
    win, 
    text="ATTENDANCE MANAGEMENT SYSTEM\nUSING MACHINE LEARNING (FACE RECOGNITION)", 
    font=("Arial", 16, "bold"), 
    bg="#f0f0f0", 
    fg="blue",
    pady=20
)
title_label.pack()

# Username Label and Entry
username_label = tk.Label(win, text="Username:", font=("Arial", 14), bg="#f0f0f0")
username_label.pack(pady=10)
username_var = tk.StringVar()
username_entry = tk.Entry(win, textvariable=username_var, font=("Arial", 14), width=30)
username_entry.pack(pady=5)

# Password Label and Entry
password_label = tk.Label(win, text="Password:", font=("Arial", 14), bg="#f0f0f0")
password_label.pack(pady=10)
password_var = tk.StringVar()
password_entry = tk.Entry(win, textvariable=password_var, font=("Arial", 14), width=30, show="*")
password_entry.pack(pady=5)

# Login Button
login_button = tk.Button(win, text="Login", command=login, font=("Arial", 14), bg="#00796b", fg="white", width=15)
login_button.pack(pady=20)

# Run the Tkinter event loop
win.mainloop()
