import tkinter as tk
from tkinter import messagebox
import os

# Function to open login.py
def open_admin_login():
    try:
        os.system('python login.py')  # This will run login.py
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open Admin Login: {str(e)}")

# Function to open final.py
def open_employee_attendance():
    try:
        os.system('python final.py')  # This will run final.py
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open Employee Attendance: {str(e)}")

# Create main window
root = tk.Tk()
root.title("ATTENDANCE Management System using Machine Learning")
root.geometry("600x400")
root.configure(bg="#f0f0f0")  # Light background

# Heading label
heading = tk.Label(root, text="ATTENDANCE Management System using Machine Learning", 
                   font=("Arial", 20, "bold"), bg="#f0f0f0", fg="blue")
heading.pack(pady=40)

# Admin Login Button
admin_button = tk.Button(root, text="ADMIN LOGIN", command=open_admin_login, 
                         font=("Arial", 14), bg="#ff9999", fg="white", width=20, height=2)
admin_button.pack(pady=20)

# Employee Attendance Button
employee_button = tk.Button(root, text="EMPLOYEE ATTENDANCE", command=open_employee_attendance, 
                            font=("Arial", 14), bg="#99ccff", fg="white", width=20, height=2)
employee_button.pack(pady=20)

# Run the Tkinter event loop
root.mainloop()
