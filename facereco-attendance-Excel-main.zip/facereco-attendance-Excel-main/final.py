import glob
import face_recognition
import numpy as np
from datetime import datetime
import cv2
import os
import sqlite3
import csv

now = datetime.now()
dtString = now.strftime("%H:%M")

cap = cv2.VideoCapture(0)
FONT = cv2.FONT_HERSHEY_COMPLEX
images = []
names = []

# Path to the images folder
path = r'C:\Users\aakan\OneDrive\Desktop\API\facereco-attendance-Excel-main\images\*.*'
for file in glob.glob(path):
    image = cv2.imread(file)
    a = os.path.basename(file)
    b = os.path.splitext(a)[0]
    names.append(b)
    images.append(image)

# Function to create or open the SQLite database
def create_database():
    conn = sqlite3.connect('attendance.db')  # Creates or connects to the database
    cursor = conn.cursor()
    # Create table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            mark TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Call to create the database when the program starts
create_database()

# Function to save attendance data to SQLite database
def save_to_database(username, date, time, mark):
    conn = sqlite3.connect('attendance.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO attendance (username, date, time, mark)
        VALUES (?, ?, ?, ?)
    ''', (username, date, time, mark))
    conn.commit()
    conn.close()

# Function to export the SQLite data to a CSV file named attendance.csv
def export_to_csv():
    conn = sqlite3.connect('attendance.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM attendance")
    data = cursor.fetchall()

    # Writing the data to a CSV file
    with open('attendance.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["ID", "Username", "Date", "Time", "Mark"])  # CSV Header
        writer.writerows(data)
    print("Data exported to attendance.csv successfully.")
    conn.close()

# Function to check if user is late or on time
def is_late_or_ontime(current_time_str, target_time_str, lateness_threshold_minutes):
    try:
        current_time = datetime.strptime(current_time_str, '%H:%M')
        target_time = datetime.strptime(target_time_str, '%H:%M')
        time_difference = current_time - target_time
        lateness_minutes = time_difference.total_seconds() / 60
        if lateness_minutes >= lateness_threshold_minutes:
            return "Late"
        else:
            return "On Time"
    except ValueError:
        return "Invalid time format. Use 'HH:MM' format (e.g., '13:45')."

# Main function to process attendance
def main(user_input):
    current_time_str = dtString
    target_time_str = '12:00'
    lateness_threshold_minutes = 6
    result = is_late_or_ontime(current_time_str, target_time_str, lateness_threshold_minutes)
    print(result)
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_time = datetime.now().strftime("%H:%M:%S")
    
    # Save to SQLite database
    save_to_database(user_input, current_date, current_time, result)

# Function to encode the images
def encoding1(images):
    encode = []
    for img in images:
        face_encodings = face_recognition.face_encodings(img)
        if face_encodings:
            encode.append(face_encodings[0])
        else:
            print("No face detected in image.")
    return encode

encodelist = encoding1(images)  # Ensure this line is executed before the loop

while True:
    ret, frame = cap.read()
    frame1 = cv2.resize(frame, (0, 0), None, 0.25, 0.25)
    face_locations = face_recognition.face_locations(frame1)
    curframe_encoding = face_recognition.face_encodings(frame1, face_locations)
    
    # Display heading on frame
    cv2.putText(frame, "MACHINE LEARNING BASED ATTENDANCE MANAGEMENT SYSTEM", 
                (50, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
    
    for encodeface, facelocation in zip(curframe_encoding, face_locations):
        results = face_recognition.compare_faces(encodelist, encodeface)
        distance = face_recognition.face_distance(encodelist, encodeface)
        match_index = np.argmin(distance)
        name = names[match_index]
        main(name)  # Call to main to record attendance
        x1, y1, x2, y2 = facelocation
        x1, y1, x2, y2 = x1 * 4, y1 * 4, x2 * 4, y2 * 4
        cv2.rectangle(frame, (y1, x1), (y2, x2), (0, 0, 255), 3)
        cv2.putText(frame, name, (y2 + 6, x2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 0, 255), 2)
    
    cv2.imshow("FRAME", frame)
    
    if cv2.waitKey(1) & 0xFF == 27:  # Press 'ESC' to exit
        break
        
# Export to CSV when the program exits
export_to_csv()

cap.release()
cv2.destroyAllWindows()
