import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from tkinter import filedialog
from tkcalendar import DateEntry
import os

# Function to load the CSV and display attendance for the selected date
def load_attendance():
    selected_date = date_entry.get()
    try:
        df = pd.read_csv('attendance.csv')  # Replace this with the path to your file
        df['Date'] = pd.to_datetime(df['Date']).dt.date  # Convert Date column to date type
        selected_date = pd.to_datetime(selected_date).date()

        filtered_df = df[df['Date'] == selected_date]
        
        if filtered_df.empty:
            messagebox.showinfo("No Data", "No attendance records found for this date.")
        else:
            for i in tree.get_children():
                tree.delete(i)
            for index, row in filtered_df.iterrows():
                tree.insert("", "end", values=list(row))

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Function to exit the app
def exit_app():
    root.quit()

# Function to go back (simulate redirect to dataload.py)
def go_back():
    root.destroy()
    os.system('python dataload.py')  # Adjust the path to your dataload.py

# Function to go home (simulate redirect to main.py)
def go_home():
    root.destroy()
    os.system('python main.py')  # Adjust the path to your main.py

# Create the main window
root = tk.Tk()
root.title("Attendance Management System Using Machine Learning")
root.geometry("800x600")

# Styling
root.configure(bg="#f0f0f0")

# Header
header_label = tk.Label(root, text="ATTENDANCE MANAGEMENT SYSTEM USING MACHINE LEARNING", font=("Arial", 20, "bold"), bg="#4B8BBE", fg="white", pady=10)
header_label.pack(fill=tk.X)

# Date Selection
date_frame = tk.Frame(root, bg="#f0f0f0")
date_frame.pack(pady=20)

date_label = tk.Label(date_frame, text="Select Date:", font=("Arial", 14), bg="#f0f0f0")
date_label.pack(side=tk.LEFT, padx=10)

date_entry = DateEntry(date_frame, width=12, background='darkblue', foreground='white', borderwidth=2, date_pattern='y-mm-dd')
date_entry.pack(side=tk.LEFT, padx=10)

load_button = tk.Button(date_frame, text="Load Attendance", command=load_attendance, font=("Arial", 12), bg="#4CAF50", fg="white")
load_button.pack(side=tk.LEFT, padx=10)

# Table to display attendance
columns = ("ID", "Name", "Date", "Time", "Status")
tree = ttk.Treeview(root, columns=columns, show="headings", height=10)
tree.heading("ID", text="ID")
tree.heading("Name", text="Name")
tree.heading("Date", text="Date")
tree.heading("Time", text="Time")
tree.heading("Status", text="Status")
tree.pack(pady=20)

# Add Scrollbar
scrollbar = ttk.Scrollbar(root, orient="vertical", command=tree.yview)
tree.configure(yscroll=scrollbar.set)
scrollbar.pack(side="right", fill="y")

# Button Frame
button_frame = tk.Frame(root, bg="#f0f0f0")
button_frame.pack(pady=20)

back_button = tk.Button(button_frame, text="Back", command=go_back, font=("Arial", 12), bg="#FFC107", fg="black", width=10)
back_button.pack(side=tk.LEFT, padx=10)

home_button = tk.Button(button_frame, text="Home", command=go_home, font=("Arial", 12), bg="#2196F3", fg="white", width=10)
home_button.pack(side=tk.LEFT, padx=10)

exit_button = tk.Button(button_frame, text="Exit", command=exit_app, font=("Arial", 12), bg="#f44336", fg="white", width=10)
exit_button.pack(side=tk.LEFT, padx=10)

# Run the application
root.mainloop()
