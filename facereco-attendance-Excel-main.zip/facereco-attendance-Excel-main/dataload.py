import sqlite3
import csv
import glob
import face_recognition
import os
import cv2
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk

# Connect to SQLite database (or create it)
def init_db():
    conn = sqlite3.connect('image_data.db')
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS images_data (
        id INTEGER PRIMARY KEY,
        name TEXT,
        path TEXT
    )
    ''')
    conn.commit()
    conn.close()

def save_to_db(name, path):
    conn = sqlite3.connect('image_data.db')
    c = conn.cursor()
    c.execute("INSERT INTO images_data (name, path) VALUES (?, ?)", (name, path))
    conn.commit()
    conn.close()

def export_to_csv():
    conn = sqlite3.connect('image_data.db')
    c = conn.cursor()
    c.execute("SELECT * FROM images_data")
    data = c.fetchall()
    
    # Export to CSV
    with open('datas.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['ID', 'Name', 'Path'])
        writer.writerows(data)
    
    messagebox.showinfo("Exported", "Data exported to datas.csv successfully!")
    conn.close()

# Initialize the SQLite database
init_db()

cap = cv2.VideoCapture(0)
images = []
names = []

# Corrected base path with raw string
base_path = r'C:\Users\aakan\OneDrive\Desktop\API\facereco-attendance-Excel-main\images'

def snapshot():
    # Capture frame and convert it to RGB
    cv2image = cv2.cvtColor(cap.read()[1], cv2.COLOR_BGR2RGB)
    img = Image.fromarray(cv2image)
    face_locations = face_recognition.face_locations(cv2image)
    
    # Save image for each face detected
    for face_location in face_locations:
        top, right, bottom, left = face_location
        im1 = img.crop((left, top, right, bottom))
        name = name_var.get().strip()  # Get name from the entry field
        if name:  # Ensure the name is not empty before saving
            image_path = os.path.join(base_path, name + '.jpg')
            im1.save(image_path)
            save_to_db(name, image_path)
            print(f"Image saved as {name}.jpg")
            updatedata()  # Update data to reflect new images
            name_var.set("")  # Clear the name entry field after saving
        else:
            print("Name is empty. Please enter a name.")

def updatedata():
    global images, names
    images.clear()  # Clear previous images
    names.clear()   # Clear previous names
    path = os.path.join(base_path, '*.*')
    
    # Load images and names again from the specified path
    for file in glob.glob(path):
        image = cv2.imread(file)
        a = os.path.basename(file)
        b = os.path.splitext(a)[0]
        names.append(b)
        images.append(image)
    
    print(f"Updated names: {names}")  # Print updated names for debugging

def show_frames():
    # Get the latest frame, resize it to 300x300, and convert it into Image
    ret, frame = cap.read()
    frame = cv2.resize(frame, (300, 300))  # Resize frame to 300x300
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(cv2image)
    
    # Convert image to PhotoImage and update the label
    imgtk = ImageTk.PhotoImage(image=img)
    label.imgtk = imgtk
    label.configure(image=imgtk)
    
    # Repeat after an interval to capture continuously
    label.after(10, show_frames)

def quitapp():
    # Release the camera and close the window
    cap.release()
    win.destroy()

def open_reports():
    try:
        os.system('python reports.py')  # This will run reports.py
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open Reports: {str(e)}")

# Create an instance of Tkinter Window or frame
win = Tk()
win.title("Face Recognition Based Attendance Management System")
win.geometry("900x700")

# Create a canvas
canvas = Canvas(win)
canvas.pack(side=LEFT, fill=BOTH, expand=True)

# Add a scrollbar to the canvas
scrollbar = Scrollbar(win, orient=VERTICAL, command=canvas.yview)
scrollbar.pack(side=RIGHT, fill=Y)

# Configure the canvas
canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

# Create a frame inside the canvas
scrollable_frame = Frame(canvas)

# Bind the frame's size changes to the canvas' scroll region
scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)

# Add the frame to the canvas window
canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

# Title Label
title_label = Label(
    scrollable_frame, 
    text="FACE RECOGNITION BASED ATTENDANCE MANAGEMENT SYSTEM", 
    font=("Helvetica", 20, "bold"), 
    bg="#ffffff", 
    fg="#000080", 
    pady=20
)
title_label.grid(row=0, column=0, columnspan=2)

# Create a Label to capture the Video frames with a 300x300 size
label = Label(scrollable_frame, bg="#b2dfdb", width=300, height=300)
label.grid(row=1, column=0, columnspan=2, padx=20, pady=10)

# Name entry field
name_label = Label(
    scrollable_frame, 
    text="Enter Name:", 
    font=("Helvetica", 14), 
    bg="#ffffff", 
    fg="#000080"
)
name_label.grid(row=2, column=0, pady=10, padx=10, sticky=E)

name_var = StringVar()  # Variable to store entered name
name_entry = Entry(scrollable_frame, textvariable=name_var, font=('calibre', 14))
name_entry.grid(row=2, column=1, pady=10, padx=10, sticky=W)

# Buttons for update, snapshot, export to CSV, and quit
button_frame = Frame(scrollable_frame, bg="#ffffff")
button_frame.grid(row=3, column=0, columnspan=2, pady=20)

update_btn = Button(
    button_frame, 
    text='Update', 
    command=updatedata, 
    font=("Helvetica", 14), 
    bg="#00796b", 
    fg="white"
)
update_btn.grid(row=0, column=0, padx=10)

snap_btn = Button(
    button_frame, 
    text='Snapshot', 
    command=snapshot, 
    font=("Helvetica", 14), 
    bg="#00796b", 
    fg="white"
)
snap_btn.grid(row=0, column=1, padx=10)

export_btn = Button(
    button_frame, 
    text='Export to CSV', 
    command=export_to_csv, 
    font=("Helvetica", 14), 
    bg="#00796b", 
    fg="white"
)
export_btn.grid(row=0, column=2, padx=10)

quit_btn = Button(
    button_frame, 
    text='Quit', 
    command=quitapp, 
    font=("Helvetica", 14), 
    bg="#d32f2f", 
    fg="white"
)
quit_btn.grid(row=0, column=3, padx=10)

# Reports button to open reports.py
reports_btn = Button(
    button_frame, 
    text='Reports', 
    command=open_reports, 
    font=("Helvetica", 14), 
    bg="#ff9800", 
    fg="white"
)
reports_btn.grid(row=0, column=4, padx=10)

# Show video frames
show_frames()

# Run the Tkinter event loop
win.mainloop()

# Release the camera when done
cap.release()
